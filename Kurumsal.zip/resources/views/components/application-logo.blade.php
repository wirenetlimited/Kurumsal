<svg viewBox="0 0 120 60" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
    <!-- Sol Kısım: Dolu Daire -->
    <circle cx="15" cy="30" r="12" fill="#1e3a8a"/>
    
    <!-- Orta Kısım: İki Eğik Çizgi (W harfi) -->
    <path d="M35 20 L45 40 L55 20 L65 40" stroke="#1e3a8a" stroke-width="4" stroke-linecap="round" fill="none"/>
    
    <!-- Sağ Kısım: H Harfi -->
    <rect x="75" y="15" width="4" height="30" fill="#1e3a8a"/>
    <rect x="75" y="28" width="20" height="4" fill="#1e3a8a"/>
    <rect x="91" y="15" width="4" height="30" fill="#1e3a8a"/>
</svg>
